package com.example.batcharquivo.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.batcharquivo.listener.JobResultListener;
import com.example.batcharquivo.repository.ParametroRepository;


@EnableBatchProcessing
@Configuration
public class MigracaoDadosJobConfig {
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private ParametroRepository repository;
	
	
	
	@Bean
	public Job migracaoDadosJob(@Qualifier("migrarLinhaStep") Step migrarLinhaStep) {
		
		return jobBuilderFactory
				.get("migracaoDadosJob")
				.listener(new JobResultListener(repository))
				.start(migrarLinhaStep)
				.incrementer(new RunIdIncrementer())
				.build();
	}
}
