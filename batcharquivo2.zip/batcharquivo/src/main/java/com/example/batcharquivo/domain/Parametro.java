package com.example.batcharquivo.domain;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="TB_PAR_PARAMETRO_GERAL")
public class Parametro {
	@Id
	@Column(name="PAR_ID_PARAMETRO")
	private Long idParametro;
	@Column(name="PAR_DT_INICIO_VIGENCIA")
	private LocalDate dtInicioVigencia; 
	@Column(name="PAR_DT_FIM_VIGENCIA")
	private LocalDate dtFimVigencia;
	@Column(name="PAR_NR_CNPJ_BANESTES")
	private Long cnpj;
	@Column(name="PAR_NM_NOME_FANTASIA")
	private String nomeFantasia;
	@Column(name="PAR_NM_RAZAO_SOCIAL")
	private String razaoSocial;
	@Column(name="PAR_NM_ENDERECO")
	private String endereco;
	@Column(name="PAR_NR_CEP")
	private Long cep;
	@Column(name="PAR_CD_MUNICIPIO_IBGE")
	private Long codigoMunicipioIbge;
	@Column(name="PAR_SG_UF")
	private String siglaUnidadeFederativa;
	@Column(name="PAR_NM_RESPONSAVEL")
	private String nomeResponsavel;
	@Column(name="PAR_NR_TELEFONE_RESP")
	private Long telefoneResponsavel;
	@Column(name="PAR_NM_EMAIL_RESP")
	private String emailResponsavel;
	@Column(name="PAR_NM_DIRETORIO_RECEB_ARQ")
	private String diretorioReceberArquivo;
	@Column(name="PAR_NM_DIRETORIO_GERAR_ARQ")
	private String diretorioGerarArquivo;
	@Column(name="PAR_NM_DIRETORIO_PROCESSADO")
	private String diretorioProcessado;
	@Column(name="PAR_NM_DIRETORIO_ERRO")
	private String diretorioErro;
	@Column(name="PAR_CD_VERSAO_LAYOUT")
	private String versaoLayoyt;
	@Column(name="PAR_VL_VALOR_MINIMO_TRAN_CPF")
	private Double valorMininimoTransacaoCpf;
	@Column(name="PAR_QT_QUANTI_MINIMA_TRAN_CPF")
	private Long quantidadeMinimaTransacaoCpf;
	@Column(name="PAR_CD_USUARIO_ATUALIZACAO")
	private String codigoUsuarioAtualizacao;
	@Column(name="PAR_NM_ROTINA_ATUALIZACAO")
	private String rotinaAtualizacao;
	@Column(name="PAR_DT_DATA_ATUALIZACAO")
	private LocalDate dtAtualizacao;
	
	
	
	
	
	
	
	
	
	public Long getIdParametro() {
		return idParametro;
	}
	public void setIdParametro(Long idParametro) {
		this.idParametro = idParametro;
	}
	public LocalDate getDtInicioVigencia() {
		return dtInicioVigencia;
	}
	public void setDtInicioVigencia(LocalDate dtInicioVigencia) {
		this.dtInicioVigencia = dtInicioVigencia;
	}
	public LocalDate getDtFimVigencia() {
		return dtFimVigencia;
	}
	public void setDtFimVigencia(LocalDate dtFimVigencia) {
		this.dtFimVigencia = dtFimVigencia;
	}
	public Long getCnpj() {
		return cnpj;
	}
	public void setCnpj(Long cnpj) {
		this.cnpj = cnpj;
	}
	public String getNomeFantasia() {
		return nomeFantasia;
	}
	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}
	public String getRazaoSocial() {
		return razaoSocial;
	}
	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public Long getCep() {
		return cep;
	}
	public void setCep(Long cep) {
		this.cep = cep;
	}
	public Long getCodigoMunicipioIbge() {
		return codigoMunicipioIbge;
	}
	public void setCodigoMunicipioIbge(Long codigoMunicipioIbge) {
		this.codigoMunicipioIbge = codigoMunicipioIbge;
	}
	public String getSiglaUnidadeFederativa() {
		return siglaUnidadeFederativa;
	}
	public void setSiglaUnidadeFederativa(String siglaUnidadeFederativa) {
		this.siglaUnidadeFederativa = siglaUnidadeFederativa;
	}
	public String getNomeResponsavel() {
		return nomeResponsavel;
	}
	public void setNomeResponsavel(String nomeResponsavel) {
		this.nomeResponsavel = nomeResponsavel;
	}
	public Long getTelefoneResponsavel() {
		return telefoneResponsavel;
	}
	public void setTelefoneResponsavel(Long telefoneResponsavel) {
		this.telefoneResponsavel = telefoneResponsavel;
	}
	public String getEmailResponsavel() {
		return emailResponsavel;
	}
	public void setEmailResponsavel(String emailResponsavel) {
		this.emailResponsavel = emailResponsavel;
	}
	public String getDiretorioReceberArquivo() {
		return diretorioReceberArquivo;
	}
	public void setDiretorioReceberArquivo(String diretorioReceberArquivo) {
		this.diretorioReceberArquivo = diretorioReceberArquivo;
	}
	public String getDiretorioGerarArquivo() {
		return diretorioGerarArquivo;
	}
	public void setDiretorioGerarArquivo(String diretorioGerarArquivo) {
		this.diretorioGerarArquivo = diretorioGerarArquivo;
	}
	public String getDiretorioProcessado() {
		return diretorioProcessado;
	}
	public void setDiretorioProcessado(String diretorioProcessado) {
		this.diretorioProcessado = diretorioProcessado;
	}
	public String getDiretorioErro() {
		return diretorioErro;
	}
	public void setDiretorioErro(String diretorioErro) {
		this.diretorioErro = diretorioErro;
	}
	public String getVersaoLayoyt() {
		return versaoLayoyt;
	}
	public void setVersaoLayoyt(String versaoLayoyt) {
		this.versaoLayoyt = versaoLayoyt;
	}
	public Double getValorMininimoTransacaoCpf() {
		return valorMininimoTransacaoCpf;
	}
	public void setValorMininimoTransacaoCpf(Double valorMininimoTransacaoCpf) {
		this.valorMininimoTransacaoCpf = valorMininimoTransacaoCpf;
	}
	public Long getQuantidadeMinimaTransacaoCpf() {
		return quantidadeMinimaTransacaoCpf;
	}
	public void setQuantidadeMinimaTransacaoCpf(Long quantidadeMinimaTransacaoCpf) {
		this.quantidadeMinimaTransacaoCpf = quantidadeMinimaTransacaoCpf;
	}
	public String getCodigoUsuarioAtualizacao() {
		return codigoUsuarioAtualizacao;
	}
	public void setCodigoUsuarioAtualizacao(String codigoUsuarioAtualizacao) {
		this.codigoUsuarioAtualizacao = codigoUsuarioAtualizacao;
	}
	public String getRotinaAtualizacao() {
		return rotinaAtualizacao;
	}
	public void setRotinaAtualizacao(String rotinaAtualizacao) {
		this.rotinaAtualizacao = rotinaAtualizacao;
	}
	public LocalDate getDtAtualizacao() {
		return dtAtualizacao;
	}
	public void setDtAtualizacao(LocalDate dtAtualizacao) {
		this.dtAtualizacao = dtAtualizacao;
	}
	
	
	
	
	
	
	

}
