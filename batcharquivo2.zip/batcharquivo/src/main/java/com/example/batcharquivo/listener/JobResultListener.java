package com.example.batcharquivo.listener;

import java.util.Optional;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.batcharquivo.domain.Parametro;
import com.example.batcharquivo.repository.ParametroRepository;

@Component
@JobScope
public class JobResultListener implements JobExecutionListener {
	
	@Autowired
	private ParametroRepository repository ;
	
	public JobResultListener(ParametroRepository repository) {
		this.repository = repository;
	}
	
	
	public void beforeJob(JobExecution jobExecution) {
		

		Optional<Parametro> optionalParametro =  repository.findById(Long.valueOf(1));
		Parametro parametro = optionalParametro.get();
		jobExecution.getExecutionContext().put("filename", parametro.getDiretorioReceberArquivo()+"/20220505.000001-276.PGCBIGCBH1");
		
		
		//File file = new File(parametro.getDiretorioReceberArquivo());
		//File afile[] = file.listFiles();
	
	   
	}

	public void afterJob(JobExecution jobExecution) {
		if (jobExecution.getStatus() == BatchStatus.COMPLETED ) {
			System.out.println("Job Finalizado");
	    }
	    else if (jobExecution.getStatus() == BatchStatus.FAILED) {
	        //job failure
	    }
	}
	

	
	
}