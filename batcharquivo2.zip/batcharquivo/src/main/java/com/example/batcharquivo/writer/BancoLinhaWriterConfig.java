package com.example.batcharquivo.writer;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.batch.item.database.ItemPreparedStatementSetter;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.batcharquivo.domain.Linha;

@Configuration
public class BancoLinhaWriterConfig {
	@Bean
	public JdbcBatchItemWriter<Linha> bancoLinhaWriter(@Qualifier("appDataSource") DataSource dataSource){
		return new JdbcBatchItemWriterBuilder<Linha>()
				.dataSource(dataSource)
				.sql("INSERT INTO TESTE (ID,MSG,DATAHORA) VALUES (?, ?, ?)")
				.itemPreparedStatementSetter(itemPreparedStatementSetter())
				.build();
	}
	
	private ItemPreparedStatementSetter<Linha> itemPreparedStatementSetter(){
		return new ItemPreparedStatementSetter<Linha>() {
			
			@Override
			public void setValues(Linha linha, PreparedStatement ps) throws SQLException{
				ps.setInt(1, 99998);
				ps.setString(2, linha.getDescricaoLinha());
				ps.setDate(3,java.sql.Date.valueOf(java.time.LocalDate.now()));
			}
		};
	}
}
