package com.example.batcharquivo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BatcharquivoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BatcharquivoApplication.class, args);
	}

}