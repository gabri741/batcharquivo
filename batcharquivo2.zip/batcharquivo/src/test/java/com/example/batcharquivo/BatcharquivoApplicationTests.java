package com.example.batcharquivo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatcharquivoApplicationTests {

	@Test
	void contextLoads() {
	}

}
