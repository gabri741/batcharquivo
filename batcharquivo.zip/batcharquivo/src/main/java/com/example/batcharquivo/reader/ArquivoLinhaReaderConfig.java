package com.example.batcharquivo.reader;

import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

import com.example.batcharquivo.domain.Linha;

@Configuration
public class ArquivoLinhaReaderConfig {
	
	@Bean
	public FlatFileItemReader<Linha> arquivoLinhaReader(){
		return new FlatFileItemReaderBuilder<Linha>()
				.name("arquivoLinhaReader")
				.resource(new FileSystemResource("files/20220505.000001.PGCBIGCBH1"))
				.delimited()
				.names("descricaoLinha")
				.targetType(Linha.class)
				.build();
	}
		

}
