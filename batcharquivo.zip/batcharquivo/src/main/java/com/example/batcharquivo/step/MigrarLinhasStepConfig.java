package com.example.batcharquivo.step;

import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.batcharquivo.domain.Linha;

@Configuration
public class MigrarLinhasStepConfig {

	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Bean
	public Step migrarLinhaStep(ItemReader<Linha> arquivoLinhaReader, ItemWriter<Linha> bancoLinhaWriter ) {
		return stepBuilderFactory
				.get("migrarLinhaStep")
				.<Linha, Linha>chunk(1)
				.reader(arquivoLinhaReader)
				.writer(bancoLinhaWriter)
				.build();
	
	}
	
}
